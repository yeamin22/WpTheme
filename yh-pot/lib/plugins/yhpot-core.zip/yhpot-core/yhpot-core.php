<?php
/**
 * Plugin Name:       Yhpot Core
 * Plugin URI:        www.meetyhsajib.com
 * Description:       This plugin used for theme core features it should be installed with the theme.
 * Version:           1.0.0
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            YH Sajib
 * Author URI:        https://www.github.com/yeamin22
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Update URI:        https://www.github.com/yeamin22/yhpot-core
 * Text Domain:       yhpot-core
 * Domain Path:       /languages
 */

/**
 * Exit if accessed directly
 */
if ( !defined( 'ABSPATH' ) ) {
    exit;
}


if ( !class_exists( "Yhpot_Core" ) ) {
    final class Yhpot_Core {


     /**
     * Plugin version
     *
     * @var string
     */
    public $version = '0.1.0';

     /**
     * Holds various class instances
     *
     * @var array
     */
    private $container = array();

        public function __construct() {

            $this->define_constants();

            register_activation_hook( __FILE__, array( $this, 'activate' ) );
            register_deactivation_hook( __FILE__, array( $this, 'deactivate' ) );

            add_action( "plugin_loaded", [ $this, "init" ] );
        }

        /**
         * Initializes the Yhpot_Core() class
         *
         * Checks for an existing Yhpot_Core() instance
         * and if it doesn't find one, creates it.
         */
        public static function instance() {
            static $instance = false;

            if ( ! $instance ) {
                $instance = new self();
            }
            return $instance;
        }

        // Class Init Action Method
        function init() {
            $this->includes();
            $this->init_hooks();

        }
        /**
         * Define the constants
         *
         * @return void
         */
        public function define_constants() {

            define( 'YHPOTCORE_TEXDOMAIN', 'yhpot-core' );
            define( 'YHPOTCORE_VERSION', $this->version );
            define( 'YHPOTCORE_FILE', __FILE__ );
            define( 'YHPOTCORE_PATH', dirname( YHPOTCORE_FILE ) );
            define( 'YHPOTCORE_INCLUDES', YHPOTCORE_PATH . '/includes' );
            define( 'YHPOTCORE_URL', plugins_url( '', YHPOTCORE_FILE ) );
            define( 'YHPOTCORE_ASSETS', YHPOTCORE_URL . '/assets' );
        }



        /**
         * Include the required files
         *
         * @return void
         */
        public function includes() {

            require_once YHPOTCORE_INCLUDES . '/Assets.php';   
            if(file_exists( YHPOTCORE_INCLUDES . '/Elementor/yhpot-elementor.php')){            
                require_once YHPOTCORE_INCLUDES . '/Elementor/yhpot-elementor.php';
            }

        }
        /**
        * Initialize the hooks
        *
         * @return void
         */
        public function init_hooks() {

            add_action( 'init', array( $this, 'init_classes' ) );

            // Localize our plugin
            add_action( 'init', array( $this, 'localization_setup' ) );
        }
        /**
         * Initialize plugin for localization
         *
         * @uses load_plugin_textdomain()
         */
        public function localization_setup() {
            load_plugin_textdomain( 'yhpot-core', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
        }

        /**
         * Instantiate the required classes
         *
         * @return void
         */
        public function init_classes() {           
            $this->container['assets'] = new YHPOT_CORE\Assets();
        }




    }
}
// Instantiate Class
$Yhpot_Core =  Yhpot_Core::instance();

?>