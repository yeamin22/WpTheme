
jQuery( window ).on( 'elementor/frontend/init', () => {

	function addCustomCss(css, context) {
		if (!context) {
			return;
		}
		var model = context.model,
			customCSS = model.get('settings').get('custom_css');
		var selector = '.elementor-element.elementor-element-' + model.get('id');

		if ('document' === model.get('elType')) {
		  selector = elementor.config.document.settings.cssWrapperSelector;
		}

		if (customCSS) {
		  css += customCSS.replace(/selector/g, selector);
		}

		return css;
	  }

	elementor.hooks.addFilter('editor/style/styleText', addCustomCss);

	function addPageCustomCss() {

		var customCSS = elementor.settings.page.model.get('custom_css');
		if (customCSS) {
			customCSS = customCSS.replace(/selector/g, elementor.config.settings.page.cssWrapperSelector);
			elementor.settings.page.getControlsCSS().elements.$stylesheetElement.append(customCSS);
		}
	}
	// elementor.settings.page.model.on('change', addPageCustomCss);
	elementor.on('preview:loaded', addPageCustomCss);






  const addHandler = ( $element ) => {
	console.log("from File");
	var swiperServices = new Swiper('.js-services', {
		slidesPerView: 3,
		  spaceBetween: 40,
			watchSlidesVisibility: true,
			noSwipingSelector: 'a',
			loop: false,
			speed: 1000,
			pagination: {
				el: '.swiper-pagination',
				type: 'bullets',
				clickable: true,
			},
			navigation: false,
			breakpoints: {
				// when window width is >= 320px
				0: {
					slidesPerView: 1,
					spaceBetween: 20
				},
				// when window width is >= 480px
				767: {
					slidesPerView: 2,
					spaceBetween: 30
				},
				// when window width is >= 640px
				1024: {
					slidesPerView: 3,
					spaceBetween: 40
				}
			}
		});
  };

  elementorFrontend.hooks.addAction( 'frontend/element_ready/yhpot_services.default', addHandler );

  const yhpotTestimonials = ($element) => {
	var swiperTestimonials = new Swiper('.js-testimonials', {
		slidesPerView: 3,
		  spaceBetween: 40,
			watchSlidesVisibility: true,
			noSwipingSelector: 'a',
			loop: false,
			speed: 1000,
			pagination: {
				el: '.swiper-pagination',
				type: 'bullets',
				clickable: true,
			},
			navigation: false,
			breakpoints: {
				// when window width is >= 320px
				0: {
					slidesPerView: 1,
					spaceBetween: 20
				},
				// when window width is >= 480px
				767: {
					slidesPerView: 2,
					spaceBetween: 30
				},
				// when window width is >= 640px
				1024: {
					slidesPerView: 3,
					spaceBetween: 40
				}
			}
		});
  }
  elementorFrontend.hooks.addAction( 'frontend/element_ready/yhpot-testimonials.default', yhpotTestimonials );




} );