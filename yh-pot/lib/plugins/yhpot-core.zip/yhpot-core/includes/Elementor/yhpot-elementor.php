<?php
/**
 * Register List Widget.
 */

function yhpot_register_list_widgets( $widgets_manager ) {
	require_once( __DIR__ . '/widgets/yhpot-hwatermark.php' );
	$widgets_manager->register( new \YHPOT_HwaterMark() );

	require_once( __DIR__ . '/widgets/yhpot-heroimage.php' );
	$widgets_manager->register( new \YHPOT_HeroImage() );

	require_once( __DIR__ . '/widgets/yhpot-services.php' );
	$widgets_manager->register( new \YHPOT_Services() );

	require_once( __DIR__ . '/widgets/yhpot-skill.php' );
	$widgets_manager->register( new \YHPOT_Skill() );

	require_once( __DIR__ . '/widgets/yhpot-resume.php' );
	$widgets_manager->register( new \YHPOT_Resume() );

	require_once( __DIR__ . '/widgets/yhpot-testimonials.php' );
	$widgets_manager->register( new \YHPOT_Testimonials() );

	require_once( __DIR__ . '/widgets/yhpot-pricing.php' );
	$widgets_manager->register( new \YHPOT_Pricing() );

	require_once( __DIR__ . '/widgets/yhpot-blog.php' );
	$widgets_manager->register( new \YHPOT_Blog() );

	require_once( __DIR__ . '/widgets/yhpot-contactinfobox.php' );
	$widgets_manager->register( new \YHPOT_ContactInfoBox() );

}
add_action( 'elementor/widgets/register', 'yhpot_register_list_widgets' );

/* Register Custom Css Control */
require_once  __DIR__ . '/widgets/yhpot-custom-css.php' ;

/* Register Widget Category For Theme */
function yhpot_register_category( $elements_manager ) {
	$elements_manager->add_category(
		'yhpot-theme',
		[
			'title' => esc_html__( 'Theme', 'textdomain' ),
			'icon' => 'yhpot-caticon',
		]
	);	
}
add_action( 'elementor/elements/categories_registered', 'yhpot_register_category' );

/* Enqueue Elementor Editor scripts */
function yhpot_editor_scripts() {
	wp_register_style( 'yhpot-el-preview', YHPOTCORE_ASSETS . '/css/elementor/yhpot-preview.css' );	
	wp_enqueue_style( 'yhpot-el-preview' );
}
add_action( 'elementor/editor/after_enqueue_styles', 'yhpot_editor_scripts' );

