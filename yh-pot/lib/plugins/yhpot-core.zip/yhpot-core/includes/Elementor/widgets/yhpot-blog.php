<?php
if ( !defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Elementor YHPOT-BLOG Widget.
 */
class YHPOT_Blog extends \Elementor\Widget_Base {

    /**
     * Get widget name.
     */
    public function get_name() {
        return 'yhpot-blog';
    }

    /**
     * Get widget title.
     */
    public function get_title() {
        return esc_html__( 'Yhpot Blog', YHPOTCORE_TEXDOMAIN );
    }

    /**
     * Get widget icon.
     */
    public function get_icon() {
      return "yhpot-caticon";
    }

    /**
     * Get custom help URL.
     */
    public function get_custom_help_url() {
        return 'https://developers.elementor.com/docs/widgets/';
    }

    /**
     * Get widget categories.
     */
    public function get_categories() {
        return ['yhpot-theme'];
    }

    /**
     * Get widget keywords.
     */
    public function get_keywords() {
        return ['oembed', 'url', 'link'];
    }

    /**
     * Register blog widget controls.
     */
    protected function register_controls() {

        $this->start_controls_section(
            'yhpot_blog_content',
            [
                'label' => esc_html__( 'Query', YHPOTCORE_TEXDOMAIN ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );




        $post_types = get_post_types(['public' => true]);
        $this->add_control(
            'yhpot_blog_post_type',
            [
                'label'     => esc_html__( 'Post type', YHPOTCORE_TEXDOMAIN ),
                'type'      => \Elementor\Controls_Manager::SELECT,    
                'default' => 'post',            
                'options'   =>  $post_types
            ]
        );
        $this->add_control(
            'yhpot_blog_post_show',
            [
                'label'     => esc_html__( 'Posts Per Page', YHPOTCORE_TEXDOMAIN ),
                'type'      => \Elementor\Controls_Manager::NUMBER,    
                'default' => 3,           
                
            ]
        );



        $this->end_controls_section();
    }

    /**
     * Render YHPOT Heading widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     */
    protected function render() {
        extract($this->get_settings_for_display());
        $query = new WP_Query(array(
            "post_status" => "publish",
            'post_type' => $yhpot_blog_post_type,
            'posts_per_page' => $yhpot_blog_post_show,
        ));       
    ?>
        <div class="blog-items row">
        <?php 
            if($query->have_posts()):
                while($query->have_posts()): $query->the_post();
        ?>
              <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                <div class="archive-item">
                  <div class="image">
                    <a href="<?php the_permalink(); ?>">
                      <img decoding="async" src="<?php the_post_thumbnail_url() ?>" alt="<?php the_title(); ?>">
                    </a>
                  </div>
                  <div class="desc">
                    <div class="category lui-subtitle">
                      <span><?php echo get_the_date(); ?></span>
                    </div>
                    <h5 class="lui-title">
                      <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                    </h5>
                    <div class="lui-text">
                      <p>
                        <?php 
                            echo wp_trim_words(get_the_content(),20,"...");
                        ?>
                      </p>
                      <div class="readmore">
                        <a href="<?php the_permalink(); ?>" class="lnk"><?php _e("Read more", YHPOTCORE_TEXDOMAIN) ?></a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

            <?php endwhile; endif; wp_reset_postdata(); ?>
         
            </div>
    <?php
    }

}