<?php
if ( !defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Elementor YHPOT-ContactInfoBox Widget.
 */
class YHPOT_ContactInfoBox extends \Elementor\Widget_Base {

    /**
     * Get widget name.
     */
    public function get_name() {
        return 'yhpot-contactinfobox';
    }

    /**
     * Get widget title.
     */
    public function get_title() {
        return esc_html__( 'Yhpot Contact Info Box', YHPOTCORE_TEXDOMAIN );
    }

    /**
     * Get widget icon.
     */
    public function get_icon() {
        return "yhpot-caticon";
    }

    /**
     * Get custom help URL.
     */
    public function get_custom_help_url() {
        return 'https://developers.elementor.com/docs/widgets/';
    }

    /**
     * Get widget categories.
     */
    public function get_categories() {
        return ['yhpot-theme'];
    }

    /**
     * Get widget keywords.
     */
    public function get_keywords() {
        return ['oembed', 'url', 'link'];
    }

    /**
     * Register oEmbed widget controls.
     */
    protected function register_controls() {

        $this->start_controls_section(
            'yhpot_contactinfobox_content',
            [
                'label' => esc_html__( 'Content', YHPOTCORE_TEXDOMAIN ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
		$this->add_control(
			'yhpot_contactinfobox_icon',
			[
				'label' => esc_html__( 'Icon', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-circle',
					'library' => 'fa-solid',
				],
				'recommended' => [
					'fa-solid' => [
						'circle',
						'dot-circle',
						'square-full',
					],
					'fa-regular' => [
						'circle',
						'map',
						'user',
						'envelope',
						'address-book',
					],
				],
			]
		);
        $this->add_control(
            'yhpot_contactinfobox_title',
            [
                'label'       => esc_html__( 'Title', YHPOTCORE_TEXDOMAIN ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'placeholder' => esc_html__( 'Title Here', YHPOTCORE_TEXDOMAIN ),
            ]
        );

        $this->add_control(
            'yhpot_contactinfobox_description',
            [
                'label'       => esc_html__( 'Info/Address', YHPOTCORE_TEXDOMAIN ),
                'type'        => \Elementor\Controls_Manager::TEXTAREA,
                'label_block' => true,
                'placeholder' => esc_html__( 'Info/Address Here', YHPOTCORE_TEXDOMAIN ),
            ]
        );




        $this->end_controls_section();

    }

    /**
     * Render YHPOT ContactInfoBox widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     */
    protected function render() {
        extract($this->get_settings_for_display());
    ?>
    <div class="numbers-item">
        <div class="icon">
        <?php \Elementor\Icons_Manager::render_icon( $yhpot_contactinfobox_icon, [ 'aria-hidden' => 'true' ] ); ?>
        </div>
        <div class="title">
            <span> <?php echo $yhpot_contactinfobox_title; ?> </span>
        </div>
        <div class="lui-text">
            <span><?php echo $yhpot_contactinfobox_description; ?></span>
        </div>
    </div>
    <?php
    }

}