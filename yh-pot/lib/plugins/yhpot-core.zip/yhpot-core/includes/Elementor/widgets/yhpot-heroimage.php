<?php
if ( !defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Elementor YHPOT-HEADING Widget.
 */
class YHPOT_HeroImage extends \Elementor\Widget_Base {

    /**
     * Get widget name.
     */
    public function get_name() {
        return 'yhpot-heroimage';
    }

    /**
     * Get widget title.
     */
    public function get_title() {
        return esc_html__( 'Yhpot Hero image', YHPOTCORE_TEXDOMAIN );
    }

    /**
     * Get widget icon.
     */
    public function get_icon() {
        return "yhpot-caticon";
    }

    /**
     * Get custom help URL.
     */
    public function get_custom_help_url() {
        return 'https://developers.elementor.com/docs/widgets/';
    }

    /**
     * Get widget categories.
     */
    public function get_categories() {
        return ['yhpot-theme'];
    }

    /**
     * Get widget keywords.
     */
    public function get_keywords() {
        return ['oembed', 'url', 'link'];
    }

    /**
     * Register oEmbed widget controls.
     */
    protected function register_controls() {

        /*
        YHPot Left Content
         */
        $this->start_controls_section(
            'yhpot_heroimage_left_scontent',
            [
                'label' => esc_html__( 'Hero Left', YHPOTCORE_TEXDOMAIN ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'yhpot_heroimage_left_hello_text',
            [
                'label'       => esc_html__( 'First Heading', YHPOTCORE_TEXDOMAIN ),
                'type'        => \Elementor\Controls_Manager::TEXTAREA,
                'default'     => esc_html__( 'Hello, My name is', YHPOTCORE_TEXDOMAIN ),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'yhpot_heroimage_left_name',
            [
                'label'       => esc_html__( 'Name', YHPOTCORE_TEXDOMAIN ),
                'type'        => \Elementor\Controls_Manager::TEXTAREA,
                'default'     => __( '<b>Zoé</b> Miller', YHPOTCORE_TEXDOMAIN ),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'yhpot_heroimage_left_designation',
            [
                'label'       => esc_html__( 'Designation', YHPOTCORE_TEXDOMAIN ),
                'type'        => \Elementor\Controls_Manager::TEXTAREA,
                'default'     => __( 'I am <strong>Web Developer</strong>', YHPOTCORE_TEXDOMAIN ),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'yhpot_heroimage_left_bio',
            [
                'label'       => esc_html__( 'Bio', YHPOTCORE_TEXDOMAIN ),
                'type'        => \Elementor\Controls_Manager::TEXTAREA,
                'default'     => __( 'From France, Paris. I have rich experience in web design, also I am good at wordpress. I love to talk with you about our unique.', YHPOTCORE_TEXDOMAIN ),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'yhpot_heroimage_left_social_icons_wrap',
            [
                'label'  => esc_html__( 'Social Icons', YHPOTCORE_TEXDOMAIN ),
                'type'   => \Elementor\Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name'        => 'yhpot_heroimage_left_social_icon',
                        'label'       => esc_html__( 'Icon', YHPOTCORE_TEXDOMAIN ),
                        'type'        => \Elementor\Controls_Manager::ICONS,
                        'default'     => [
                            'value'   => 'fas fa-circle',
                            'library' => 'fa-solid',
                        ],
                        'recommended' => [
                            'fa-solid'   => [
                                'circle',
                                'dot-circle',
                                'square-full',
                            ],
                            'fa-regular' => [
                                'circle',
                                'dot-circle',
                                'square-full',
                            ],
                        ],
                    ],
                    [
                        'name'        => 'yhpot_heroimage_left_social_link',
                        'label'       => esc_html__( 'Link', YHPOTCORE_TEXDOMAIN ),
                        'type'        => \Elementor\Controls_Manager::URL,
                        'options'     => ['url', 'is_external', 'nofollow'],
                        'default'     => [
                            'url'         => 'https://github.com/yeamin22',
                            'is_external' => true,
                            'nofollow'    => true,
                        ],
                        'label_block' => true,
                    ],

                ],

            ]
        );

        $this->add_control(
            'yhpot_heroimage_left_downloadbtn_text',
            [
                'label'       => esc_html__( 'Download Button Text', YHPOTCORE_TEXDOMAIN ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => esc_html__( 'Download CV', YHPOTCORE_TEXDOMAIN ),
                'placeholder' => esc_html__( 'Type your button text here', YHPOTCORE_TEXDOMAIN ),
            ]
        );

        $this->add_control(
            'yhpot_heroimage_left_downloadbtn_link',
            [
                'label' => esc_html__( 'Cv Button Link', YHPOTCORE_TEXDOMAIN ),
                'type'  => \Elementor\Controls_Manager::URL,
            ]
        );

        $this->add_control(
            'yhpot_heroimage_left_skillbtn_text',
            [
                'label'       => esc_html__( 'Skill Button Text', YHPOTCORE_TEXDOMAIN ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => esc_html__( 'My skill', YHPOTCORE_TEXDOMAIN ),
                'placeholder' => esc_html__( 'Type your button text here', YHPOTCORE_TEXDOMAIN ),
            ]
        );

        $this->add_control(
            'yhpot_heroimage_left_skillbtn_link',
            [
                'label' => esc_html__( 'Skill Button Link', YHPOTCORE_TEXDOMAIN ),
                'type'  => \Elementor\Controls_Manager::URL,
            ]
        );

        $this->end_controls_section();
        /*
        Hero Right Content
         */
        $this->start_controls_section(
            'yhpot_heroimage_content',
            [
                'label' => esc_html__( 'Hero Right', YHPOTCORE_TEXDOMAIN ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'yhpot_heroimage_mainimage',
            [
                'label'   => esc_html__( 'Choose Image', YHPOTCORE_TEXDOMAIN ),
                'type'    => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'yhpot_heroimage_experiencebox',
            [
                'label'       => esc_html__( 'Experience', YHPOTCORE_TEXDOMAIN ),
                'type'        => \Elementor\Controls_Manager::TEXTAREA,
                'default'     => __( 'Years of <strong>Experience</strong>', YHPOTCORE_TEXDOMAIN ),
                'label_block' => true,
                'placeholder' => esc_html__( 'Type your experience here', YHPOTCORE_TEXDOMAIN ),
            ]
        );

        $this->add_control(
            'yhpot_heroimage_projectbox',
            [
                'label'       => esc_html__( 'Projects', YHPOTCORE_TEXDOMAIN ),
                'type'        => \Elementor\Controls_Manager::TEXTAREA,
                'label_block' => true,
                'default'     => __( 'Completed <strong>Projects</strong>', YHPOTCORE_TEXDOMAIN ),
                'placeholder' => esc_html__( 'Type your projects here', YHPOTCORE_TEXDOMAIN ),
            ]
        );
        $this->end_controls_section();

        /* Style Tab */

        $this->start_controls_section(
            'yhpot_heroimage_style',
            [
                'label' => esc_html__( 'Design Images', YHPOTCORE_TEXDOMAIN ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'yhpot_heroimage_designiamge_1',
            [
                'label'   => esc_html__( 'Choose Image', YHPOTCORE_TEXDOMAIN ),
                'type'    => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );
        $this->add_control(
            'yhpot_heroimage_designiamge_2',
            [
                'label'   => esc_html__( 'Choose Image', YHPOTCORE_TEXDOMAIN ),
                'type'    => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );
        $this->end_controls_section();
    }

    /**
     * Render YHPOT Heading widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     */
    protected function render() {
        extract( $this->get_settings_for_display() );
        ?>
            <div class="section hero-started">
                <div class="content">
                    <div class="titles">
                        <div class="lui-subtitle">
                            <span>
                                <?php echo $yhpot_heroimage_left_hello_text; ?>
                            </span>
                        </div>
                        <h1 class="title" data-splitting="chars">
                            <span>
                                <?php echo $yhpot_heroimage_left_name; ?>
                            </span>
                        </h1>
                        <div class="label lui-subtitle">
                            <?php echo $yhpot_heroimage_left_designation; ?>
                        </div>
                    </div>
                    <div class="description">
                        <div>
                            <p>
                                <?php echo $yhpot_heroimage_left_bio; ?>
                            </p>
                        </div>
                        <div class="social-links">
                            <?php
                            foreach ( $yhpot_heroimage_left_social_icons_wrap as $social_icon ) {
                                        ?>
                                            <a target="_blank" rel="nofollow"
                                                href="<?php echo $social_icon['yhpot_heroimage_left_social_link']['url']; ?>">
                                                <?php \Elementor\Icons_Manager::render_icon( $social_icon['yhpot_heroimage_left_social_icon'], ['aria-hidden' => 'true'] );?>
                                            </a>
                                        <?php
                            }
                        ?>
                        </div>
                    </div>
                    <div class="bts">
                        <a target="_blank" href="<?php echo $yhpot_heroimage_left_downloadbtn_link; ?>" class="btn">
                            <span><?php echo $yhpot_heroimage_left_downloadbtn_text; ?></span>
                        </a>
                        <a href="<?php echo $yhpot_heroimage_left_skillbtn_link; ?>"
                            class="btn-lnk"><?php echo $yhpot_heroimage_left_skillbtn_text; ?> </a>
                    </div>
                </div>

                <div class="slide">
                    <img decoding="async" src="<?php print_r( $yhpot_heroimage_mainimage['url'] )?>"
                        alt="<?php echo esc_html( "YH SAJIB" ); ?>">
                    <span class="circle circle-1"></span>
                    <span class="circle img-1"
                        style="background-image: url(<?php echo $yhpot_heroimage_designiamge_1['url']; ?>);"></span>
                    <span class="circle img-2"
                        style="background-image: url(<?php echo $yhpot_heroimage_designiamge_2['url']; ?>);"></span>
                    <span class="circle img-3"
                        style="background-image: url(<?php echo $yhpot_heroimage_designiamge_2['url']; ?>);"></span>
                    <div class="info-list">
                        <ul>
                            <li>
                                <?php echo $yhpot_heroimage_experiencebox; ?>
                            </li>
                            <li>
                                <?php echo $yhpot_heroimage_projectbox; ?>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="v-line-block"><span></span></div>
            </div>
        <?php

            }

        }