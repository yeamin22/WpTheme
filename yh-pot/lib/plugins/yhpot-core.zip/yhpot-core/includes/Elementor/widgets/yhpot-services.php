<?php
if ( !defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Elementor YHPOT-Services Widget.
 */
class YHPOT_Services extends \Elementor\Widget_Base {

    public function __construct( $data = [], $args = null ) {
        parent::__construct( $data, $args );

        wp_register_script( 'yhpot-elmentor-fron', YHPOTCORE_ASSETS . "/js/elementor/yhpot-elementor.js", ['elementor-frontend'], '1.0.0', true );
     

    }

    /**
     * Get widget name.
     */
    public function get_name() {
        return 'yhpot_services';
    }

    /**
     * Get widget title.
     */
    public function get_title() {
        return esc_html__( 'Yhpot Services', YHPOTCORE_TEXDOMAIN );
    }

    /**
     * Get widget icon.
     */
    public function get_icon() {
        return "yhpot-caticon";
    }

    /**
     * Get custom help URL.
     */
    public function get_custom_help_url() {
        return 'https://developers.elementor.com/docs/widgets/';
    }

    /**
     * Get widget categories.
     */
    public function get_categories() {
        return ['yhpot-theme'];
    }

    /**
     * Get widget keywords.
     */
    public function get_keywords() {
        return ['oembed', 'url', 'link'];
    }

    public function get_script_depends() {
        return ['yhpot-elmentor-fron'];
    }
    /**
     * Register services widget controls.
     */
    protected function register_controls() {

        $this->start_controls_section(
            'yhpot_services',
            [
                'label' => esc_html__( 'Services', YHPOTCORE_TEXDOMAIN ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();
   
        $repeater->add_control(
			'yhpot_services_category',
			[
				'label' => esc_html__( 'Service Category', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'WordPress' , 'textdomain' ),
				'label_block' => true,
			]
		);
        $repeater->add_control(
			'yhpot_services_title',
			[
				'label' => esc_html__( 'Service Title', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Bug Fixing' , 'textdomain' ),
				'label_block' => true,
			]
		);
        $repeater->add_control(
			'yhpot_services_desc',
			[
				'label' => esc_html__( 'Service Description', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,				
				'label_block' => true,
			]
		);
        $repeater->add_control(
			'yhpot_services_pricing_text',
			[
				'label' => esc_html__( 'Pricing Text', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::TEXT,				
				'label_block' => true,
			]
		);
        $repeater->add_control(
			'yhpot_services_pricing_url',
			[
				'label' => esc_html__( 'Pricing Link', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::URL,							
			]
		);
        $this->add_control(
			'yhpot_services_lists',
			[
				'label' => esc_html__( 'Services', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),	
				'title_field' => '{{{ yhpot_services_category }}}',
			]
		);
        $this->end_controls_section();	


                /* Style Tab */

                $this->start_controls_section(
                    'yhpot_services_styles',
                    [
                        'label' => esc_html__( 'Design Images', YHPOTCORE_TEXDOMAIN ),
                        'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
                    ]
                );
                $this->add_control(
                    'yhpot_services_styles_img1',
                    [
                        'label'   => esc_html__( 'Choose Image', YHPOTCORE_TEXDOMAIN ),
                        'type'    => \Elementor\Controls_Manager::MEDIA,
                        'default' => [
                            'url' => \Elementor\Utils::get_placeholder_image_src(),
                        ],
                    ]
                );
               
                $this->end_controls_section();
    }

    /**
     * Render YHPOT Heading widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     */
    protected function render() {
        extract($this->get_settings_for_display());
        ?>
  					<div class="swiper-container js-services">
  						<div class="swiper-wrapper">
                        <?php 
                            foreach($yhpot_services_lists as $services):
                        ?>
  							<div class="swiper-slide">
  								<div class="services-item">
  									<div class="lui-subtitle">
  										<span><?php echo $services['yhpot_services_category']; ?> </span>
  									</div>
  									<div class="icon"></div>
  									<h5 class="lui-title">
  										<span> <?php echo $services['yhpot_services_title']; ?> </span>
  									</h5>
  									<div class="lui-text">
  									<?php echo $services['yhpot_services_desc']; ?>
  									</div>
  									<a href="<?php echo $services['yhpot_services_pricing_url']['url']; ?>" class="lnk"> <?php echo $services['yhpot_services_pricing_text']; ?></a>
  									<div class="image" style="background-image: url(<?php echo $yhpot_services_styles_img1['url']; ?>);"></div>
  								</div>
  							</div>
                        <?php 
                            endforeach;
                        ?>
  						</div>
  						<div class="swiper-pagination"></div>
  					</div>
<?php
     

    }

}