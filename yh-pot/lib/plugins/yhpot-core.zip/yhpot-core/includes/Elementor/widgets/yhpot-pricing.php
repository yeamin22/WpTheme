<?php
if ( !defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Elementor YHPOT_Pricing Widget.
 */
class YHPOT_Pricing extends \Elementor\Widget_Base {

    /**
     * Get widget name.
     */
    public function get_name() {
        return 'yhpot-pricing';
    }

    /**
     * Get widget title.
     */
    public function get_title() {
        return esc_html__( 'Yhpot Pricing', YHPOTCORE_TEXDOMAIN );
    }

    /**
     * Get widget icon.
     */
    public function get_icon() {
        return "yhpot-caticon";
    }

    /**
     * Get custom help URL.
     */
    public function get_custom_help_url() {
        return 'https://developers.elementor.com/docs/widgets/';
    }

    /**
     * Get widget categories.
     */
    public function get_categories() {
        return ['yhpot-theme'];
    }

    /**
     * Get widget keywords.
     */
    public function get_keywords() {
        return ['oembed', 'url', 'link'];
    }

    /**
     * Register oEmbed widget controls.
     */
    protected function register_controls() {

        $this->start_controls_section(
            'yhpot_pricing_content',
            [
                'label' => esc_html__( 'Pricing', YHPOTCORE_TEXDOMAIN ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'yhpot_packpage_name',
            [
                'label'       => esc_html__( 'Package Name', YHPOTCORE_TEXDOMAIN ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'placeholder' => esc_html__( 'Package Here', YHPOTCORE_TEXDOMAIN ),
            ]
        );
        $this->add_control(
            'yhpot_packpage_badge',
            [
                'label' => esc_html__( 'Badge Name', YHPOTCORE_TEXDOMAIN ),
                'type'  => \Elementor\Controls_Manager::TEXT,
            ]
        );
        $this->add_control(
            'yhpot_packpage_price',
            [
                'label'       => esc_html__( 'Package Price', YHPOTCORE_TEXDOMAIN ),
                'type'        => \Elementor\Controls_Manager::NUMBER,
                'placeholder' => esc_html__( 'Package Here', YHPOTCORE_TEXDOMAIN ),
            ]
        );

        $this->add_control(
            'yhpot_packpage_type',
            [
                'label'   => esc_html__( 'Package Type', 'textdomain' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => 'Hour',
                'options' => [
                    'Hour'  => esc_html__( 'Hour', 'textdomain' ),
                    'Week'  => esc_html__( 'Week', 'textdomain' ),
                    'Month' => esc_html__( 'Month', 'textdomain' ),
                ],
            ]
        );
        $this->add_control(
            'yhpot_packpage_description',
            [
                'label'       => esc_html__( 'Package Description', YHPOTCORE_TEXDOMAIN ),
                'type'        => \Elementor\Controls_Manager::TEXTAREA,
                'label_block' => true,
                'placeholder' => esc_html__( 'Package Description', YHPOTCORE_TEXDOMAIN ),
            ]
        );

        $this->add_control(
            'yhpot_packpage_services',
            [
                'label' => esc_html__( 'Package Services', YHPOTCORE_TEXDOMAIN ),
                'type'  => \Elementor\Controls_Manager::WYSIWYG,
            ]
        );

        $this->add_control(
            'yhpot_packpage_orderbtn',
            [
                'label'       => esc_html__( 'Button Text', YHPOTCORE_TEXDOMAIN ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'placeholder' => esc_html__( 'Order Button Text', YHPOTCORE_TEXDOMAIN ),
                'default'     => esc_html__( 'Start Porject', YHPOTCORE_TEXDOMAIN ),
            ]
        );
        $this->add_control(
            'yhpot_packpage_orderbtn_link',
            [
                'label' => esc_html__( 'Button Link', YHPOTCORE_TEXDOMAIN ),
                'type'  => \Elementor\Controls_Manager::URL,

            ]
        );
        $this->end_controls_section();
        /* Style Tab */

        $this->start_controls_section(
            'yhpot_pricing_style',
            [
                'label' => esc_html__( 'Design Images', YHPOTCORE_TEXDOMAIN ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'yhpot_pricing_style_img',
            [
                'label'   => esc_html__( 'Choose Image', YHPOTCORE_TEXDOMAIN ),
                'type'    => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->end_controls_section();

    }

    /**
     * Render YHPOT Heading widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     */
    protected function render() {
        extract( $this->get_settings_for_display() );
        ?>
        <div class="pricing-col">

            <?php
        if ( !empty( $yhpot_packpage_badge ) ) {
                    ?>
            <div class="label">
                <span> <?php echo $yhpot_packpage_badge; ?> </span>
            </div>
            <?php
        }
                ?>
            <div class="pricing-item">
                <div class="lui-subtitle">
                    <span> <?php echo $yhpot_packpage_name; ?> </span>
                </div>
                <div class="icon"></div>
                <div class="price">
                    <span><?php echo $yhpot_packpage_price; ?> <b>$</b>
                    </span>
                    <em><?php echo $yhpot_packpage_type; ?></em>
                </div>
                <div class="lui-text">
                    <div>
                        <p><?php echo $yhpot_packpage_description; ?></p>
                    </div>
                </div>
                <div class="list">
                    <div>
                        <?php echo $yhpot_packpage_services; ?>
                    </div>
                </div>
                <a href="<?php echo $yhpot_packpage_orderbtn_link['url']; ?>" class="btn btn-solid">
                    <span><?php echo $yhpot_packpage_orderbtn; ?></span>
                </a>
                <div class="bg-img" style="background-image: url(<?php echo $yhpot_pricing_style_img['url']; ?>);"></div>
            </div>
        </div>
<?php

    }

}