<?php
if ( !defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Elementor YHPOT-Testimonials Widget.
 */
class YHPOT_Testimonials extends \Elementor\Widget_Base {

    /**
     * Get widget name.
     */
    public function get_name() {
        return 'yhpot-testimonials';
    }

    /**
     * Get widget title.
     */
    public function get_title() {
        return esc_html__( 'Yhpot Testimonials', YHPOTCORE_TEXDOMAIN );
    }

    /**
     * Get widget icon.
     */
    public function get_icon() {
      return "yhpot-caticon";
    }

    /**
     * Get custom help URL.
     */
    public function get_custom_help_url() {
        return 'https://developers.elementor.com/docs/widgets/';
    }

    /**
     * Get widget categories.
     */
    public function get_categories() {
        return ['yhpot-theme'];
    }

    /**
     * Get widget keywords.
     */
    public function get_keywords() {
        return ['oembed', 'url', 'link'];
    }

    /**
     * Register services widget controls.
     */
    protected function register_controls() {

        $this->start_controls_section(
            'yhpot_testimonials_content',
            [
                'label' => esc_html__( 'Testimonials', YHPOTCORE_TEXDOMAIN ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
			'yhpot_testimonials_client_name',
			[
				'label' => esc_html__( 'CLient Name', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::TEXT,				
				'label_block' => true,
			]
		);
        $repeater->add_control(
			'yhpot_testimonials_client_designation',
			[
				'label' => esc_html__( 'Designation', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::TEXT,		
                'label_block' => true,					
			]
		);
        $repeater->add_control(
			'yhpot_testimonials_client_img',
			[
				'label' => esc_html__( 'Choose Image', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
        $repeater->add_control(
			'yhpot_testimonials_client_review',
			[
				'label' => esc_html__( 'Client Review', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,				
				'label_block' => true,
			]
		);
        

        $this->add_control(
			'yhpot_testimonials',
			[
				'label' => esc_html__( 'Testimonials', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),	
				'title_field' => '{{{ yhpot_testimonials_client_name }}}',
			]
		);
        $this->end_controls_section();	
    }

    /**
     * Render YHPOT Heading widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     */
    protected function render() {
        extract($this->get_settings_for_display());
        ?>
            <div class="swiper-container js-testimonials">
              <div class="swiper-wrapper">
                <?php 
                    foreach($yhpot_testimonials as $testimonials){
                ?>
                <div class="swiper-slide">
                  <div class="testimonials-item">
                    <div class="image">
                      <img decoding="async" src="<?php echo $testimonials['yhpot_testimonials_client_img']['url']; ?>" alt="<?php $testimonials['yhpot_testimonials_client_name']; ?>">
                      <div class="icon">
                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="44px" height="34px">
                          <path fill-rule="evenodd" stroke-width="2px" stroke="rgb(0, 0, 0)" fill="rgb(41, 165, 135)" d="M17.360,8.325 C15.490,5.563 11.616,4.762 8.705,6.536 C6.901,7.635 5.815,9.533 5.826,11.567 C5.828,14.854 8.637,17.516 12.101,17.515 C13.290,17.513 14.456,17.192 15.460,16.587 C14.967,17.975 14.049,19.457 12.537,20.942 C11.934,21.533 11.951,22.476 12.574,23.048 C13.198,23.619 14.192,23.604 14.794,23.012 C20.384,17.515 19.658,11.539 17.360,8.333 L17.360,8.325 ZM32.407,8.325 C30.538,5.563 26.663,4.762 23.752,6.536 C21.949,7.635 20.863,9.533 20.873,11.567 C20.875,14.854 23.685,17.516 27.148,17.515 C28.338,17.513 29.503,17.192 30.508,16.587 C30.015,17.975 29.097,19.457 27.585,20.942 C26.982,21.533 26.999,22.476 27.622,23.048 C28.245,23.619 29.239,23.604 29.842,23.012 C35.432,17.515 34.706,11.539 32.407,8.333 L32.407,8.325 Z"></path>
                        </svg>
                      </div>
                    </div>
                    <div class="text lui-text">
                      <div>
                            <?php echo $testimonials['yhpot_testimonials_client_review']; ?>
                      </div>
                    </div>
                    <div class="info">
                      <h6 class="name">
                        <span><?php echo $testimonials['yhpot_testimonials_client_name']; ?></span>
                      </h6>
                      <div class="author">
                        <span><?php echo $testimonials['yhpot_testimonials_client_designation']; ?></span>
                      </div>
                    </div>
                    <div class="bg-img" style="background-image: url(assets/images/pat-2.png);"></div>
                  </div>
                </div>

                <?php } ?>
              </div>
              <div class="swiper-pagination"></div>
            </div>
<?php     

    }

}