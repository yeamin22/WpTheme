<?php
if ( !defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Elementor YHPOT-HEADING Widget.
 */
class YHPOT_Resume extends \Elementor\Widget_Base {

    /**
     * Get widget name.
     */
    public function get_name() {
        return 'yhpot-resume';
    }

    /**
     * Get widget title.
     */
    public function get_title() {
        return esc_html__( 'Yhpot Resume', YHPOTCORE_TEXDOMAIN );
    }

    /**
     * Get widget icon.
     */
    public function get_icon() {
        return "yhpot-caticon";
    }

    /**
     * Get custom help URL.
     */
    public function get_custom_help_url() {
        return 'https://developers.elementor.com/docs/widgets/';
    }

    /**
     * Get widget categories.
     */
    public function get_categories() {
        return ['yhpot-theme'];
    }

    /**
     * Get widget keywords.
     */
    public function get_keywords() {
        return ['oembed', 'url', 'link'];
    }

    /**
     * Register oEmbed widget controls.
     */
    protected function register_controls() {

        $this->start_controls_section(
            'yhpot_resume_content',
            [
                'label' => esc_html__( 'Resume', YHPOTCORE_TEXDOMAIN ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );



        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'yhpot_resume_platform',
            [
                'label'       => esc_html__( 'Platform/Institute', YHPOTCORE_TEXDOMAIN ),
                'type'        => \Elementor\Controls_Manager::TEXT,                
                'label_block' => true,
                'placeholder' => esc_html__( 'Platform/Institute Name Here', YHPOTCORE_TEXDOMAIN ),
                'default' => esc_html__( 'CoderHouse Courses', YHPOTCORE_TEXDOMAIN ),
            ]
        );
        $repeater->add_control(
            'yhpot_resume_program_name',
            [
                'label'       => esc_html__( 'Program Name', YHPOTCORE_TEXDOMAIN ),
                'type'        => \Elementor\Controls_Manager::TEXT,                
                'label_block' => true,
                'placeholder' => esc_html__( 'Program Name Here', YHPOTCORE_TEXDOMAIN ),
                'default' => esc_html__( 'Backend Programming', YHPOTCORE_TEXDOMAIN ),
            ]
        );
        $repeater->add_control(
            'yhpot_resume_program_year',
            [
                'label'       => esc_html__( 'Year', YHPOTCORE_TEXDOMAIN ),
                'type'        => \Elementor\Controls_Manager::TEXT,                
                'label_block' => true,
                'placeholder' => esc_html__( 'Joining and ending year', YHPOTCORE_TEXDOMAIN ),
                'default' => esc_html__( '2014 - 2016', YHPOTCORE_TEXDOMAIN ),
            ]
        );
        $repeater->add_control(
            'yhpot_resume_description',
            [
                'label'       => esc_html__( 'Description', YHPOTCORE_TEXDOMAIN ),
                'type'        => \Elementor\Controls_Manager::TEXT,                
                'label_block' => true,
                'placeholder' => esc_html__( 'Description here', YHPOTCORE_TEXDOMAIN ),
                'default' => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', YHPOTCORE_TEXDOMAIN ),
            ]
        );

        $this->add_control(
			'yhpot_resume_lists',
			[
				'label' => esc_html__( 'Programs', YHPOTCORE_TEXDOMAIN ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),	
				'title_field' => '{{{ yhpot_resume_program_name }}}',
			]
		);

        
        $this->end_controls_section();

    }

    /**
     * Render YHPOT Heading widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     */
    protected function render() {
       extract($this->get_settings_for_display());
   ?>
                <div class="history-items">
                <?php 
                $a = 1;               
                    foreach($yhpot_resume_lists as $programs){
                        $opened = $a === 1 ? "opened" : "";
                        $active = $a === 1 ? "active" : "";
                ?>
                  <div class="history-item lui-collapse-item <?php echo $opened; ?>" >
                    <h6 class="name lui-collapse-btn <?php echo  $active; ?>">
                      <span> <?php echo $programs['yhpot_resume_platform']; ?> </span>
                    </h6>
                    <div class="history-content">
                      <div class="subname">
                        <span> <?php echo $programs["yhpot_resume_program_name"]; ?> </span>
                      </div>
                      <div class="date lui-subtitle">
                        <span> <?php echo $programs['yhpot_resume_program_year']; ?></span>
                      </div>
                      <div class="text">
                        <div>
                          <?php echo $programs['yhpot_resume_description']; ?>
                        </div>
                      </div>
                    </div>
                  </div>       
                  
                <?php ++$a; } ?>
                </div>
   <?php  
    }

}