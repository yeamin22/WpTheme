<?php
if ( !defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Elementor YHPOT-HEADING Widget.
 */
class YHPOT_HwaterMark extends \Elementor\Widget_Base {

    /**
     * Get widget name.
     */
    public function get_name() {
        return 'yhpot-hwatermark';
    }

    /**
     * Get widget title.
     */
    public function get_title() {
        return esc_html__( 'Heading Watermark', YHPOTCORE_TEXDOMAIN );
    }

    /**
     * Get widget icon.
     */
    public function get_icon() {
        return "yhpot-caticon";
    }

    /**
     * Get custom help URL.
     */
    public function get_custom_help_url() {
        return 'https://developers.elementor.com/docs/widgets/';
    }

    /**
     * Get widget categories.
     */
    public function get_categories() {
        return ['yhpot-theme'];
    }

    /**
     * Get widget keywords.
     */
    public function get_keywords() {
        return ['oembed', 'url', 'link'];
    }

    /**
     * Register oEmbed widget controls.
     */
    protected function register_controls() {

        $this->start_controls_section(
            'yhpot_heading_content',
            [
                'label' => esc_html__( 'Content', YHPOTCORE_TEXDOMAIN ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'yhpot_heading_title',
            [
                'label'       => esc_html__( 'Title', YHPOTCORE_TEXDOMAIN ),
                'type'        => \Elementor\Controls_Manager::TEXTAREA,
                'input_type'  => 'text',
                'label_block' => true,
                'placeholder' => esc_html__( 'Heading Here', YHPOTCORE_TEXDOMAIN ),
                'default' => "Wordpress Expert",
            ]
        );


        $this->end_controls_section();

		/* Style Tab */


		$this->start_controls_section(
			'yhpot_heading_style_tab',
			[
				'label' => esc_html__( 'Heading', YHPOTCORE_TEXDOMAIN ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'yhpot_heading_color',
			[
				'label' => esc_html__( 'Color', YHPOTCORE_TEXDOMAIN ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .yhpot_heading' => 'color: {{VALUE}};'					
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'yhpot_heading_typography',
				'selector' => '{{WRAPPER}} .lui-bgtitle',
                'fields_options' => [
                    // Inner control name
                    'font_weight' => [
                        // Inner control settings
                        'default' => '700',
                    ],
                    'font_family' => [
                        'default' => 'Caveat',
                    ],
                    'font_size'   => [
                        'default' => [ 'unit' => 'px', 'size' => 260 ],
                    ],
                    'line_height'   => [
                        'default' => ['size' => 1],
                    ],
                ],
			]
		);
        $this->add_control(
			'yhpot_hwatermark_dimensions',
			[
				'label' => esc_html__( 'Margin', YHPOTCORE_TEXDOMAIN ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [					
					'{{WRAPPER}} .lui-bgtitle' => 'top: {{TOP}}{{UNIT}}; left: {{LEFT}}{{UNIT}};',
                  
				],
			]
		);

		$this->end_controls_section();
    }

    /**
     * Render YHPOT Heading widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     */
    protected function render() {
        extract($this->get_settings_for_display());
    ?>
            <div class="lui-bgtitle">
              <span><?php echo $yhpot_heading_title; ?></span>
            </div>     
    <?php
    }

}