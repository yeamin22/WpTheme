<?php
if ( !defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Elementor YHPOT-HEADING Widget.
 */
class YHPOT_Skill extends \Elementor\Widget_Base {

    /**
     * Get widget name.
     */
    public function get_name() {
        return 'yhpot-skill';
    }

    /**
     * Get widget title.
     */
    public function get_title() {
        return esc_html__( 'Yhpot Skill', YHPOTCORE_TEXDOMAIN );
    }

    /**
     * Get widget icon.
     */
    public function get_icon() {
        return "yhpot-caticon";
    }

    /**
     * Get custom help URL.
     */
    public function get_custom_help_url() {
        return 'https://developers.elementor.com/docs/widgets/';
    }

    /**
     * Get widget categories.
     */
    public function get_categories() {
        return ['yhpot-theme'];
    }

    /**
     * Get widget keywords.
     */
    public function get_keywords() {
        return ['oembed', 'url', 'link'];
    }

    /**
     * Register oEmbed widget controls.
     */
    protected function register_controls() {

        $this->start_controls_section(
            'yhpot_skill_content',
            [
                'label' => esc_html__( 'Skill', YHPOTCORE_TEXDOMAIN ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'yhpot_skill_name',
            [
                'label'       => esc_html__( 'Skill', YHPOTCORE_TEXDOMAIN ),
                'type'        => \Elementor\Controls_Manager::TEXT,                
                'label_block' => true,
                'placeholder' => esc_html__( 'Skill Name Here', YHPOTCORE_TEXDOMAIN ),
                'default' => esc_html__( 'PHP', YHPOTCORE_TEXDOMAIN ),
            ]
        );
        $this->add_control(
            'yhpot_skill_percentage',
            [
                'label'       => esc_html__( 'Skill Percentage', YHPOTCORE_TEXDOMAIN ),
                'type'        => \Elementor\Controls_Manager::NUMBER,  
                'label_block' => true,
                'placeholder' => esc_html__( 'Skill Lavel Percentage', YHPOTCORE_TEXDOMAIN ),
                'default' => 90,
            ]
        );
        $this->add_control(
            'yhpot_skill_description',
            [
                'label'       => esc_html__( 'Skill Description', YHPOTCORE_TEXDOMAIN ),
                'type'        => \Elementor\Controls_Manager::WYSIWYG,               
                'placeholder' => esc_html__( 'Skill Description', YHPOTCORE_TEXDOMAIN ),
            ]
        );
        
        $this->end_controls_section();

    }

    /**
     * Render YHPOT Heading widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     */
    protected function render() {
       extract($this->get_settings_for_display());
   ?>
                <div class="skills-items">
                  <div class="skills-item">
                    <h6 class="name">
                      <span> <?php echo $yhpot_skill_name; ?> </span>
                    </h6>
                    <div class="text">
                      <div>
                      <?php echo $yhpot_skill_description; ?>
                      </div>
                    </div>
                    <div class="dots">
                      <div class="dot" style="width: <?php echo $yhpot_skill_percentage; ?>%;">
                        <span></span>
                      </div>
                    </div>
                    <div class="value">
                      <span class="num"><?php echo $yhpot_skill_percentage; ?> <span>%</span>
                      </span>
                    </div>
                  </div>
                </div>
   <?php  
    }

}